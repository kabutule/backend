import { useEffect,useState } from "react";
import SpaceContainer from './planet/SpaceContainer/SpaceContainer';

function Plants(){
  return(
    <div className="Plants">
      <SpaceContainer />
    </div>
  )
}

export default Plants;