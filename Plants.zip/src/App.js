// src/App.js
import React, { useEffect, useState } from 'react';
import Plants from "./Plants"

function App() {
  

  return (
    <div>
      <Plants />
    </div>
  );
}

export default App;
